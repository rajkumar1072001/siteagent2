package com.siteagent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val e = sbn.notification.extras
        val title = e.getCharSequence("android.title")?.toString() ?: ""
        val text = e.getCharSequence("android.text")?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (x: Exception) { sbn.packageName }
        val line = "$app: $title - $text"
        Store.addNote(line)
        val p = Store.prefs(this)
        if (p.getBoolean("auto", false)) {
            Speaker.init(this)
            Speaker.say(line, p.getString("lang", "ta-IN")!!)
        }
    }
}
