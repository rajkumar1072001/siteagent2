package com.siteagent
import android.content.Context

object Work {
    private fun role(k: String) = when (k) {
        "report" -> "Write a neat daily site report from the engineer's notes: date, work done, manpower, materials used, issues, safety, plan for tomorrow. If key details are missing, use placeholders like [number]. Compact plain text."
        "worker" -> "Give construction workers short, simple, step-by-step tasks for today and clear safety rules (helmet, harness, scaffolding, excavation, electrical, curing). Use very simple words."
        "estimate" -> "Estimate materials and cost for the described civil work (Indian practice: cement bags, sand, aggregate, bricks, steel, labour). Show the formula and assumptions step by step, give a rough range, and say rates vary by location and must be verified by the engineer."
        else -> "Write a polite, simple reply to the engineer's client about progress, cost or schedule using only the project details given. Never invent numbers; say the engineer will confirm missing facts."
    }

    fun run(c: Context, kind: String, input: String, done: (String) -> Unit) {
        val p = Store.prefs(c)
        Thread {
            val proj = (p.getString("proj", "") ?: "").ifBlank { "none" }
            val sys = "You assist a civil engineer in India. ${role(kind)} Reply in " +
                "${Store.langName(p.getString("lang", "ta-IN")!!)} (technical terms may stay in English). Project details: $proj."
            val r = try {
                Claude.ask(p.getString("key", "") ?: "", sys, input.ifBlank { "Please go ahead with sensible defaults." })
            } catch (e: Exception) { "Network error: ${e.message}" }
            done(r)
        }.start()
    }
}
