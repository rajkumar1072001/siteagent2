package com.siteagent
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Claude {
    fun ask(key: String, system: String, user: String): String {
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 600).put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
        val con = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        con.requestMethod = "POST"
        con.setRequestProperty("x-api-key", key)
        con.setRequestProperty("anthropic-version", "2023-06-01")
        con.setRequestProperty("content-type", "application/json")
        con.doOutput = true; con.connectTimeout = 15000; con.readTimeout = 60000
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        if (con.responseCode >= 400) return "Error ${con.responseCode}"
        val t = con.inputStream.bufferedReader().readText()
        return JSONObject(t).getJSONArray("content").getJSONObject(0).getString("text")
    }
}
