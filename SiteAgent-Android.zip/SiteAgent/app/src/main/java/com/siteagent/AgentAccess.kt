package com.siteagent
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AgentAccess : AccessibilityService() {
    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }

    companion object {
        @Volatile var inst: AgentAccess? = null
        private val nodes = HashMap<Int, AccessibilityNodeInfo>()

        @Synchronized fun dump(): String {
            val s = inst ?: return "(accessibility service is OFF)"
            val root = s.rootInActiveWindow ?: return "(no screen content)"
            nodes.clear()
            val sb = StringBuilder("app: ${root.packageName}\nid|type|text|flags\n")
            walk(root, sb)
            return sb.toString()
        }

        private fun walk(n: AccessibilityNodeInfo?, sb: StringBuilder) {
            if (n == null || nodes.size >= 80) return
            val txt = (n.text ?: n.contentDescription)?.toString()?.replace("\n", " ")?.take(80)
            val interesting = n.isClickable || n.isEditable || n.isScrollable || !txt.isNullOrBlank()
            if (n.isVisibleToUser && interesting) {
                val id = nodes.size + 1
                nodes[id] = n
                val f = listOfNotNull(if (n.isClickable) "click" else null, if (n.isEditable) "edit" else null,
                    if (n.isScrollable) "scroll" else null).joinToString(",")
                sb.append("$id|${n.className?.toString()?.substringAfterLast('.')}|${txt ?: ""}|$f\n")
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), sb)
        }

        @Synchronized fun tap(id: Int): String {
            val n = nodes[id] ?: return "no such id"
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "ok"
            val r = Rect(); n.getBoundsInScreen(r)
            val s = inst ?: return "service off"
            val p = Path().apply { moveTo(r.centerX().toFloat(), r.centerY().toFloat()) }
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
            return if (s.dispatchGesture(g, null, null)) "ok(gesture)" else "failed"
        }

        @Synchronized fun typeText(id: Int, text: String): String {
            val n = nodes[id] ?: return "no such id"
            n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
            return if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "ok" else "failed"
        }

        @Synchronized fun enter(id: Int): String {
            val n = nodes[id] ?: return "no such id"
            if (Build.VERSION.SDK_INT >= 30 &&
                n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return "ok"
            return "failed (tap the search/send button instead)"
        }

        @Synchronized fun scroll(dir: String): String {
            val n = nodes.values.firstOrNull { it.isScrollable } ?: return "nothing scrollable"
            val a = if (dir == "up") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            return if (n.performAction(a)) "ok" else "failed"
        }

        fun global(a: Int): String = if (inst?.performGlobalAction(a) == true) "ok" else "failed"
    }
}
