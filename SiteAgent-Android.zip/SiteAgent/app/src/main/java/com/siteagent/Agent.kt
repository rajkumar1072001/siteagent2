package com.siteagent
import android.content.Context
import android.os.PowerManager
import org.json.JSONObject

object Agent {
    @Volatile var cancel = false
    @Volatile var running = false

    private fun system(lang: String) = """You control an Android phone by voice for a civil engineer in India. Each turn you get the GOAL, ACTIONS SO FAR, and the CURRENT SCREEN as numbered elements (id|type|text|flags).
Reply with ONLY one JSON object: {"say":"short sentence in ${Store.langName(lang)} to speak aloud (optional, empty if nothing to say)","action":{...}}
Actions (use exactly these):
{"type":"open_app","name":"app name in English as on the launcher"}
{"type":"call","to":"contact name or number"}
{"type":"sms","to":"contact name or number","text":"message"}
{"type":"tap","id":N}  {"type":"type","id":N,"text":"..."}  {"type":"enter","id":N}  {"type":"scroll","dir":"down|up"}
{"type":"back"}  {"type":"home"}  {"type":"wait"}  {"type":"done"}
Rules: Prefer open_app, call and sms over tapping. When the goal is finished, or the goal is only a question or reading notifications/SMS/calls (data is given on the first turn), put the answer in "say" and use {"type":"done"}. Keep spoken text short and natural, no markdown. Use element ids exactly as shown. Never make payments or transfers, never delete data; if asked, say you can’t do that and finish with done. If information is missing, say so and finish with done."""

    fun run(c: Context, goal: String) {
        if (running) return
        running = true; cancel = false
        wake(c)
        Thread {
            try { loop(c, goal) }
            catch (e: Exception) { speak(c, "Error: ${e.message}") }
            finally { running = false }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun wake(c: Context) {
        val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
        pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "siteagent:screen")
            .acquire(60_000)
    }

    private fun lang(c: Context) = Store.prefs(c).getString("lang", "ta-IN")!!
    private fun speak(c: Context, t: String) { Speaker.init(c); Speaker.say(t, lang(c)) }

    private fun parse(s: String): JSONObject? {
        val a = s.indexOf('{'); val b = s.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try { JSONObject(s.substring(a, b + 1)) } catch (e: Exception) { null }
    }

    private fun loop(c: Context, goal: String) {
        val key = Store.prefs(c).getString("key", "") ?: ""
        val sys = system(lang(c))
        val base = "Notifications:\n${Store.notesText()}\n\nSMS:\n${Data.sms(c)}\n\nCalls:\n${Data.calls(c)}\n\n"
        val hist = ArrayDeque<String>()
        for (step in 1..15) {
            if (cancel) { speak(c, "OK, stopped."); return }
            val user = "GOAL: $goal\n\n" + (if (step == 1) base else "") +
                "ACTIONS SO FAR:\n" + hist.joinToString("\n") + "\n\nCURRENT SCREEN:\n" + AgentAccess.dump()
            val reply = Claude.ask(key, sys, user)
            val j = parse(reply)
            if (j == null) { speak(c, if (reply.startsWith("Error")) reply else "I didn’t understand."); return }
            val say = j.optString("say")
            if (say.isNotBlank()) speak(c, say)
            val a = j.optJSONObject("action") ?: return
            if (a.optString("type") == "done") return
            val res = Actions.exec(c, a)
            hist.addLast("$step. $a -> $res")
            while (hist.size > 10) hist.removeFirst()
            Thread.sleep(1500)
        }
        speak(c, "That took too many steps, so I stopped.")
    }
}
