package com.siteagent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

class CallReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val st = i.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val p = Store.prefs(c)
        val lang = p.getString("lang", "ta-IN")!!
        when (st) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: return
                val now = System.currentTimeMillis()
                if (num == last && now - lastT < 5000) return
                last = num; lastT = now
                ringing = num; answered = false
                Speaker.init(c)
                Speaker.say(Speaker.callLine(lang, Data.name(c, num) ?: num), lang)
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> if (ringing != null) answered = true
            TelephonyManager.EXTRA_STATE_IDLE -> {
                val n = ringing
                if (n != null && !answered && p.getBoolean("autoreply", false)) autoReply(c, n)
                ringing = null
            }
        }
    }

    private fun autoReply(c: Context, num: String) {
        val now = System.currentTimeMillis()
        if (now - (replied[num] ?: 0L) < 3_600_000L) return
        replied[num] = now
        val msg = (Store.prefs(c).getString("autoreply_msg", "") ?: "")
            .ifBlank { "I’m on site right now and can’t take your call. I’ll call you back soon." }
        Actions.sms(c, num, msg)
    }

    companion object {
        var last = ""; var lastT = 0L
        var ringing: String? = null; var answered = false
        val replied = HashMap<String, Long>()
    }
}
