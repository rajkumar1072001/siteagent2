package com.siteagent
import android.content.Context

object Store {
    private val notes = ArrayDeque<String>()
    @Synchronized fun addNote(s: String) { notes.addFirst(s); while (notes.size > 30) notes.removeLast() }
    @Synchronized fun notesText(): String = notes.take(15).joinToString("\n")
    fun prefs(c: Context) = c.getSharedPreferences("agent", Context.MODE_PRIVATE)
    fun langName(l: String) = when (l) { "ta-IN" -> "Tamil"; "hi-IN" -> "Hindi"; else -> "English" }
}
