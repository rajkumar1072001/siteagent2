package com.siteagent
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class VoiceService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var on = false
    private var awaiting = false
    private var lock: PowerManager.WakeLock? = null
    private val stopWords = listOf("stop", "நிறுத்து", "நிறுத்துங்கள்", "रुको", "बंद करो")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        startFg()
        if (!on) {
            on = true
            Speaker.init(this)
            lock = (getSystemService(POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "siteagent:mic").apply { acquire() }
            rec = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
            listen(500)
        }
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("voice", "Voice control", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "voice").setContentTitle("Site Agent is listening")
            .setContentText("Say the wake word, then your command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private fun lang() = Store.prefs(this).getString("lang", "ta-IN")!!

    private fun listen(delay: Long) {
        h.postDelayed({
            if (!on) return@postDelayed
            if (Speaker.busy) { listen(500); return@postDelayed }
            try {
                rec?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang())
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                    putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 1500L)
                })
            } catch (e: Exception) { listen(1500) }
        }, delay)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(r: Bundle?) {
            val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) handle(t)
            listen(300)
        }
        override fun onError(e: Int) {
            if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
            if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) rec?.cancel()
            listen(when (e) {
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> 3000L
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1500L
                else -> 300L
            })
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(b: Bundle?) {}
        override fun onEvent(t: Int, b: Bundle?) {}
    }

    private fun handle(text: String) {
        val t = text.lowercase()
        if (stopWords.any { t.contains(it) }) { Agent.cancel = true; Speaker.stop(); awaiting = false; return }
        if (Agent.running) return
        if (awaiting) { awaiting = false; Agent.run(this, text); return }
        val wakes = (Store.prefs(this).getString("wake", "") ?: "").lowercase().split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val w = wakes.firstOrNull { t.contains(it) } ?: return
        val cmd = text.substring(minOf(text.length, t.indexOf(w) + w.length)).trim(' ', ',', '.', '!')
        if (cmd.length > 2) Agent.run(this, cmd)
        else {
            awaiting = true
            Speaker.say(Speaker.readyLine(lang()), lang())
            h.postDelayed({ awaiting = false }, 12000)
        }
    }

    override fun onDestroy() {
        on = false
        h.removeCallbacksAndMessages(null)
        rec?.destroy()
        lock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
