package com.siteagent
import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = AtomicInteger(0)
    val busy: Boolean get() = pending.get() > 0

    private fun dec() { pending.updateAndGet { if (it > 0) it - 1 else 0 } }

    fun init(c: Context) {
        if (tts != null) return
        tts = TextToSpeech(c.applicationContext) { st ->
            ready = st == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { dec() }
                override fun onError(id: String?) { dec() }
            })
        }
    }

    fun say(text: String, lang: String) {
        if (!ready || text.isBlank()) return
        tts?.language = Locale.forLanguageTag(lang)
        pending.incrementAndGet()
        val r = tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "u" + System.nanoTime())
        if (r != TextToSpeech.SUCCESS) dec()
    }

    fun stop() { tts?.stop(); pending.set(0) }

    fun callLine(lang: String, who: String) = when (lang) {
        "ta-IN" -> "$who இடமிருந்து அழைப்பு வருகிறது"
        "hi-IN" -> "$who का कॉल आ रहा है"
        else -> "Incoming call from $who"
    }
    fun readyLine(lang: String) = when (lang) { "ta-IN" -> "சொல்லுங்கள்"; "hi-IN" -> "बोलिए"; else -> "Yes, tell me" }
}
