package com.siteagent
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telephony.SmsManager
import org.json.JSONObject

object Actions {
    fun exec(c: Context, a: JSONObject): String = try {
        when (a.optString("type")) {
            "open_app" -> openApp(c, a.optString("name"))
            "tap" -> AgentAccess.tap(a.optInt("id"))
            "type" -> AgentAccess.typeText(a.optInt("id"), a.optString("text"))
            "enter" -> AgentAccess.enter(a.optInt("id"))
            "scroll" -> AgentAccess.scroll(a.optString("dir"))
            "back" -> AgentAccess.global(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> AgentAccess.global(AccessibilityService.GLOBAL_ACTION_HOME)
            "call" -> call(c, a.optString("to"))
            "sms" -> sms(c, a.optString("to"), a.optString("text"))
            "wait" -> "ok"
            else -> "unknown action"
        }
    } catch (e: Exception) { "error: ${e.message}" }

    private fun ctx(c: Context): Context = AgentAccess.inst ?: c

    private fun openApp(c: Context, name: String): String {
        val pm = c.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val q = name.lowercase().trim()
        val hit = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "app not found"
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "cannot launch"
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx(c).startActivity(i)
        return "opened ${hit.loadLabel(pm)}"
    }

    private fun number(c: Context, who: String): String? {
        if (who.count { it.isDigit() } >= 5) return who.filter { it.isDigit() || it == '+' }
        c.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.NUMBER), "${Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$who%"), null)?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun call(c: Context, who: String): String {
        val n = number(c, who) ?: return "contact not found: $who"
        val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx(c).startActivity(i)
        return "calling $who"
    }

    @Suppress("DEPRECATION")
    fun sms(c: Context, who: String, text: String): String {
        val n = number(c, who) ?: return "contact not found: $who"
        val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        sm.sendMultipartTextMessage(n, null, sm.divideMessage(text), null, null)
        return "sms sent to $who"
    }
}
