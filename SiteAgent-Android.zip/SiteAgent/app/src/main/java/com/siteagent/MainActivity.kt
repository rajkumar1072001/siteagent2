package com.siteagent
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.*

class MainActivity : Activity() {
    private val langs = listOf("ta-IN", "en-IN", "hi-IN")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Speaker.init(this)
        val p = Store.prefs(this)
        if (!p.contains("wake")) p.edit().putString("wake", "agent,ஏஜென்ட்,ஏஜெண்ட்,एजेंट,hey claude").apply()

        fun field(hint: String, k: String) = EditText(this).apply {
            this.hint = hint; setText(p.getString(k, ""))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { p.edit().putString(k, s.toString().trim()).apply() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 60) }
        val cur = p.getString("lang", "ta-IN")!!
        val langBtn = btn("Language: $cur") {}
        langBtn.setOnClickListener {
            val n = langs[(langs.indexOf(p.getString("lang", "ta-IN")) + 1) % langs.size]
            p.edit().putString("lang", n).apply(); langBtn.text = "Language: $n"
        }
        val auto = Switch(this).apply {
            text = "Auto-read new notifications aloud"; isChecked = p.getBoolean("auto", false)
            setOnCheckedChangeListener { _, v -> p.edit().putBoolean("auto", v).apply() }
        }
        val test = field("Type a test command", "test_cmd")
        val items = listOf(
            field("Anthropic API key", "key"),
            field("Wake words (comma separated)", "wake"),
            langBtn, auto,
            btn("1. Grant permissions") {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_SMS,
                    Manifest.permission.SEND_SMS, Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.POST_NOTIFICATIONS), 1)
            },
            btn("2. Notification access") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            btn("3. Accessibility (screen control)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            btn("4. Display over other apps") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            },
            btn("5. Battery: don’t restrict") {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            },
            btn("▶ Start voice control") { startForegroundService(Intent(this, VoiceService::class.java)) },
            btn("■ Stop voice control") { startService(Intent(this, VoiceService::class.java).setAction("STOP")) },
            test,
            btn("Run test command") { Agent.run(this, test.text.toString()) }
        )
        items.forEach { col.addView(it) }
        val proj = field("Project details (name, place, stage, budget)", "proj").apply { minLines = 3 }
        val ask = field("What do you need? (e.g. today’s work details)", "work_in").apply { minLines = 2 }
        val result = TextView(this).apply { textSize = 16f; setTextIsSelectable(true) }
        fun work(kind: String) {
            result.text = "Thinking…"
            Work.run(this, kind, ask.text.toString()) { r ->
                runOnUiThread { result.text = r; if (kind != "report") Speaker.say(r, p.getString("lang", "ta-IN")!!) }
            }
        }
        val extras = listOf<android.view.View>(
            TextView(this).apply { text = "\nCalls"; textSize = 18f },
            Switch(this).apply {
                text = "Auto-SMS reply to missed calls"; isChecked = p.getBoolean("autoreply", false)
                setOnCheckedChangeListener { _, v -> p.edit().putBoolean("autoreply", v).apply() }
            },
            field("Auto-reply message (optional)", "autoreply_msg"),
            TextView(this).apply { text = "\nSite work tools"; textSize = 18f },
            proj, ask,
            btn("📝 Daily report") { work("report") },
            btn("👷 Worker tasks & safety") { work("worker") },
            btn("🧮 Material / cost estimate") { work("estimate") },
            btn("💬 Client reply") { work("client") },
            result
        )
        extras.forEach { col.addView(it) }
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
