# Site Agent (Android) - hands-free voice control
Build the APK with the GitHub Actions workflow, install it, then in the app:
1. Paste your Anthropic API key.
2. Tap steps 1 to 5 in order (permissions, notification access, accessibility, overlay, battery).
   In the Accessibility list, open "Site Agent" and turn it ON.
3. Tap "Start voice control". Keep the phone unlocked or without a PIN lock for screen control.
4. Say the wake word then a command, e.g. "agent, WhatsApp-ல ரமேஷுக்கு நாளை வருகிறேன்னு அனுப்பு",
   "agent, call Ramesh", "agent, read my notifications", "agent, open Maps". Say "stop" to cancel.
